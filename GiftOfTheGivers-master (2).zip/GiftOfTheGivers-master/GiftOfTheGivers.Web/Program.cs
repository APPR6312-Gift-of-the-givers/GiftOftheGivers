using GiftOfTheGivers.Web.Data;
using GiftOfTheGivers.Web.Models;
using GiftOfTheGivers.Web.Services;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.UI.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// --- Database: EF Core InMemory provider ---
// The POE explicitly allows in-memory storage for the prototype, and it means
// markers/lecturers can run this instantly with no SQL Server install required.
// Swap this for UseSqlServer(connectionString) later when moving beyond the prototype.
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseInMemoryDatabase("GiftOfTheGiversPrototype"));

// --- ASP.NET Core Identity: real authentication, password hashing, roles ---
builder.Services.AddIdentity<ApplicationUser, IdentityRole>(options =>
    {
        // Relaxed password rules so demo credentials stay simple, as this is a prototype.
        options.Password.RequiredLength = 6;
        options.Password.RequireNonAlphanumeric = false;
        options.Password.RequireUppercase = false;
        options.SignIn.RequireConfirmedAccount = false;
    })
    .AddEntityFrameworkStores<ApplicationDbContext>()
    .AddDefaultTokenProviders();

builder.Services.ConfigureApplicationCookie(options =>
{
    options.LoginPath = "/Account/Login";
    options.AccessDeniedPath = "/Account/AccessDenied";
});



builder.Services.AddControllersWithViews();
builder.Services.AddHttpClient<TaxCertificateService>();

var app = builder.Build();

// --- Seed roles, demo users, and sample data on startup ---
using (var scope = app.Services.CreateScope())
{
    await SeedData.InitializeAsync(scope.ServiceProvider);
}

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
